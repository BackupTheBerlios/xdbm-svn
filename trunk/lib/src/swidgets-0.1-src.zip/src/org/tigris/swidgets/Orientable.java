/*
 * Orientable.java
 *
 * Created on 17 August 2002, 01:04
 */

package org.tigris.swidgets;

/**
 *
 * @author  Bob Tarling
 */
public interface Orientable {
    public void setOrientation(Orientation orientation);
}
