/*
 *
 * ====================================================================
 *
 * Copyright 2004 The Apache Software Foundation 
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package org.apache.commons.i18n;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

/**
 * The <code>MessageManager</code> provides methods for retrieving localized
 * messages and adding custom message providers. 
 * This class should not be called directly for other purposes than registering a custom
 * {@link MessageProvider} or retrieving information about available
 * message entries.
 * <p>
 * To access localized messages a subclass of the {@link LocalizedBundle} class
 * such as <code>LocalizedText </code> should be used:
 * 
 * <pre>
 * LocalizedText welcome = new LocalizedText(&quot;welcome&quot;); 
 * // Get the german translacion of the retrieved welcome text 
 * System.out.println(welcome.getText(Locale.GERMAN));       
 * </pre>
 * 
 * <p>
 * You can call {@link MessageManager#getText(String,String,Object[],Locale) getText} directly,
 * but if you do so, you have to ensure that the given entry key really
 * exists and to deal with the {@link MessageNotFound} exception that will 
 * be thrown if you try to access a not existing entry.</p>
 * 
 */
public class MessageManager {
    static final String INTERNAL_MESSAGE_NOT_FOUND = "Internal I18n error: Message not found";
    
    static final String MESSAGE_NOT_FOUND = "messageNotFound";
    static final String NO_MESSAGE_ENTRIES_FOUND = "noMessageEntriesFound";
    static final String MESSAGE_ENTRY_NOT_FOUND = "messageEntryNotFound";
    static final String RESOURCE_BUNDLE_NOT_FOUND = "resourceBundleNotFound";
    public static final String MESSAGE_PARSING_ERROR = "messageParsingError";

    public static final ResourceBundle INTERNAL_MESSAGES = ResourceBundle.getBundle("messages", Locale.getDefault());
    
    private static List messageProviders = new ArrayList();

    static {
        // Add default message providers
        messageProviders.add(new XMLMessageProvider());
        messageProviders.add(new ResourceBundleMessageProvider());
    }

    /**
     * Add a custom <code>{@link MessageProvider}</code> to the
     * <code>MessageManager</code>. It will be incorporated in later calls of
     * the {@link MessageManager#getText(String,String,Object[],Locale) getText}
     * or {@link #getEntries(String,Locale) getEntries}methods.
     * 
     * @param messageProvider
     *            The <code>MessageProvider</code> to be added.
     */
    public static void addMessageProvider(MessageProvider messageProvider) {
        messageProviders.add(messageProvider);
    }

    /**
     * Iterates over all registered message providers in order to find the given
     * entry in the requested message bundle.
     * 
     * @param id
     *            The identifier that will be used to retrieve the message
     *            bundle
     * @param entry
     *            The desired message entry
     * @param arguments
     *            The dynamic parts of the message that will be evaluated using
     *            the standard java text formatting abilities.
     * @param locale
     *            The locale in which the message will be printed
     * @exception MessageNotFoundException
     *                Will be thrown if no message bundle can be found for the
     *                given id or if the desired message entry is missing in the
     *                retrieved bundle
     * @return The localized text
     */
    public static String getText(String id, String entry, Object[] arguments,
            Locale locale) throws MessageNotFoundException {
        MessageNotFoundException exception = null;
        for (Iterator i = messageProviders.iterator(); i.hasNext();) {
            try {
                String text = ((MessageProvider) i.next()).getText(id, entry,
                        locale);
                return MessageFormat.format(text, arguments);
            } catch (MessageNotFoundException e) {
                exception = e;
            }
        }
        throw exception;
    }

    /**
     * Iterates over all registered message providers in order to find the given
     * entry in the requested message bundle.
     * 
     * @param id
     *            The identifier that will be used to retrieve the message
     *            bundle
     * @param entry
     *            The desired message entry
     * @param arguments
     *            The dynamic parts of the message that will be evaluated using
     *            the standard java text formatting abilities.
     * @param locale
     *            The locale in which the message will be printed
     * @param defaultText
     *            If no message bundle or message entry could be found for the
     *            specified parameters, the default text will be returned.
     * @return The localized text or the default text if the message could not
     *         be found
     */
    public static String getText(String id, String entry, Object[] arguments,
            Locale locale, String defaultText) {
        try {
            String text = getText(id, entry, arguments, locale);
            return MessageFormat.format(text, arguments);
        } catch (MessageNotFoundException e) {
            return defaultText;
        }
    }

    /**
     * Returns a map containing all available message entries for the given
     * locale. The map contains keys of type {@link String}containing the keys
     * of the available message entries and values of type {@link String}
     * containing the localized message entries.
     */
    public static Map getEntries(String id, Locale locale)
            throws MessageNotFoundException {
        MessageNotFoundException exception = null;
        for (Iterator i = messageProviders.iterator(); i.hasNext();) {
            try {
                Map entries = ((MessageProvider) i.next()).getEntries(id,
                        locale);
                return entries;
            } catch (MessageNotFoundException e) {
                exception = e;
            }
        }
        throw exception;
    }
}