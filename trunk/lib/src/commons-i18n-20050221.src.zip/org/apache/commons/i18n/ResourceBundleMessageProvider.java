/*
*
* ====================================================================
*
* Copyright 2004 The Apache Software Foundation 
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*
*/
package org.apache.commons.i18n;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * The <code>ResourceBundleMessageProvider</code> deals with messages defined in 
 * resource bundles. Messages defined in resource bundles can be grouped together
 * by adding the entry key at the end of the message key separated by a dot.
 */
public class ResourceBundleMessageProvider implements MessageProvider {
    private static Logger logger = Logger.getLogger(ResourceBundleMessageProvider.class.getName());

    private static List installedResourceBundles = new ArrayList();

    /* (non-Javadoc)
     * @see org.apache.commons.i18n.MessageProvider#getText(java.lang.String, java.lang.String, java.util.Locale)
     */
    public String getText(String id, String entry, Locale locale) throws MessageNotFoundException {
        String text = null;
        for ( Iterator i = installedResourceBundles.iterator(); i.hasNext(); ) {
            String baseName = (String)i.next();
            try {
                ResourceBundle resourceBundle = ResourceBundle.getBundle(baseName, locale);
                try {
                    return resourceBundle.getString(id+"."+entry);
                } catch ( ClassCastException e ) {
                    // ignore all entries that are not of type String
                } catch ( MissingResourceException e ) {
                    // skip resource bundle if it is not containing the desired entry
                }
            } catch ( MissingResourceException e ) {
                logger.log(
                        Level.WARNING, 
                        MessageFormat.format(
                                MessageManager.INTERNAL_MESSAGES.getString(MessageManager.RESOURCE_BUNDLE_NOT_FOUND),
                                new String[] { baseName })); 
                i.remove();
            }
        }
        throw new MessageNotFoundException(MessageFormat.format(
                MessageManager.INTERNAL_MESSAGES.getString(MessageManager.NO_MESSAGE_ENTRIES_FOUND),
                new String[] { id })); 
    }

    /* (non-Javadoc)
     * @see org.apache.commons.i18n.MessageProvider#getEntries(java.lang.String, java.util.Locale)
     */
    public Map getEntries(String id, Locale locale) {
        String messageIdentifier = id+".";
        Map entries = null;
        for ( Iterator i = installedResourceBundles.iterator(); i.hasNext(); ) {
            String baseName = (String)i.next();
            try {
                ResourceBundle resourceBundle = ResourceBundle.getBundle(baseName, locale);
                Enumeration keys = resourceBundle.getKeys();
                while ( keys.hasMoreElements() ) {
                    String key = (String)keys.nextElement();
                    if ( key.startsWith(messageIdentifier) ) {
                        if ( entries == null ) {
                            entries = new HashMap(); 
                        }
                        entries.put(key.substring(messageIdentifier.length()), resourceBundle.getString(key));
                    }
                }
            } catch ( MissingResourceException e ) {
                logger.log(
                        Level.WARNING, 
                        MessageFormat.format(
                                MessageManager.INTERNAL_MESSAGES.getString(MessageManager.RESOURCE_BUNDLE_NOT_FOUND),
                                new String[] { baseName })); 
            }
        }
        if ( entries == null ) {
            throw new MessageNotFoundException(MessageFormat.format(
                    MessageManager.INTERNAL_MESSAGES.getString(MessageManager.NO_MESSAGE_ENTRIES_FOUND),
                    new String[] { id })); 
        }
        return entries;
    }
    
    /**
     * Installs a new resource bundle containing messages for a specific locale 
     * with the given name.
     * 
     * @param baseName the name of the resource bundle. This name will be used to 
     * find the resource bundle by using the java mechanisms for loading resource bundles
     * and to uninstall or update the messages contained in the resource bundle.
     * 
     */
    public static void install(String baseName) {
        if ( !installedResourceBundles.contains(baseName) ) 
            installedResourceBundles.add(baseName); 
    }
    
    /**
     * @param baseName unique identifier for the resource bundle to uninstall
     */
    public static void uninstall(String baseName) {
        installedResourceBundles.remove(baseName);
    }
    
    /**
     * Update the resources specified by the given unique identifier.
     * As the messages defined in resource bundles are not cached by the
     * current implementation, calling this method has no effect.
     * This may change in future versions. 
     * @param baseName unique identifier for the resource bundle to update
     */
    public static void update(String baseName) {
        uninstall(baseName);
        install(baseName);
    }
}