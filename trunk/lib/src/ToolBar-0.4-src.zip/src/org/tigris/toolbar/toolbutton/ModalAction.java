/*
 * ButtonAction.java
 *
 * Created on 02 March 2003, 00:23
 */

package org.tigris.toolbar.toolbutton;

/**
 * An interface purely to act as an indicator of a modal action
 *
 * @author ButtonAction
 */
public interface ModalAction {
}
